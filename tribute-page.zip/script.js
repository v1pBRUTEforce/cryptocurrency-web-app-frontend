document.addEventListener("DOMContentLoaded", () => {
  const textInput = document.getElementById("text-input")
  const checkBtn = document.getElementById("check-btn")
  const result = document.getElementById("result")

  // Function to check if a string is a palindrome
  function isPalindrome(str) {
    // Remove all non-alphanumeric characters and convert to lowercase
    const cleanStr = str.replace(/[^a-zA-Z0-9]/g, "").toLowerCase()

    // Check if the cleaned string is a palindrome
    const reversedStr = cleanStr.split("").reverse().join("")
    return cleanStr === reversedStr
  }

  // Event listener for the check button
  checkBtn.addEventListener("click", () => {
    const inputText = textInput.value

    // Check if input is empty
    if (!inputText) {
      alert("Please input a value")
      return
    }

    // Check if the input is a palindrome
    const palindromeCheck = isPalindrome(inputText)

    // Display the result
    if (palindromeCheck) {
      result.textContent = `${inputText} is a palindrome`
      result.className = "palindrome"
    } else {
      result.textContent = `${inputText} is not a palindrome`
      result.className = "not-palindrome"
    }
  })

  // Allow pressing Enter key to check palindrome
  textInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      checkBtn.click()
    }
  })
})
