<?php
require_once 'config.php';

// Check if user is logged in
redirectIfNotLoggedIn();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $user_id = $_SESSION['user_id'];
    $crypto_id = sanitizeInput($_POST['crypto_id']);
    $type = sanitizeInput($_POST['type']); // 'buy', 'sell', or 'transfer'
    $amount = floatval($_POST['amount']);
    $price = floatval($_POST['price']);
    
    // Validate input
    if (empty($crypto_id) || empty($type) || $amount <= 0) {
        $response = [
            'success' => false,
            'message' => "Invalid input data."
        ];
    } else {
        try {
            // Start transaction
            $pdo->beginTransaction();
            
            // Insert transaction record
            $stmt = $pdo->prepare("
                INSERT INTO transactions (user_id, crypto_id, type, amount, price, transaction_date)
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$user_id, $crypto_id, $type, $amount, $price]);
            
            // Update portfolio
            if ($type == 'buy') {
                // Check if user already has this crypto in portfolio
                $stmt = $pdo->prepare("
                    SELECT * FROM portfolio WHERE user_id = ? AND crypto_id = ?
                ");
                $stmt->execute([$user_id, $crypto_id]);
                
                if ($stmt->rowCount() > 0) {
                    // Update existing portfolio entry
                    $stmt = $pdo->prepare("
                        UPDATE portfolio 
                        SET amount = amount + ?, 
                            last_updated = NOW() 
                        WHERE user_id = ? AND crypto_id = ?
                    ");
                    $stmt->execute([$amount, $user_id, $crypto_id]);
                } else {
                    // Create new portfolio entry
                    $stmt = $pdo->prepare("
                        INSERT INTO portfolio (user_id, crypto_id, amount, last_updated)
                        VALUES (?, ?, ?, NOW())
                    ");
                    $stmt->execute([$user_id, $crypto_id, $amount]);
                }
            } elseif ($type == 'sell') {
                // Check if user has enough of this crypto
                $stmt = $pdo->prepare("
                    SELECT amount FROM portfolio 
                    WHERE user_id = ? AND crypto_id = ?
                ");
                $stmt->execute([$user_id, $crypto_id]);
                $portfolio = $stmt->fetch();
                
                if (!$portfolio || $portfolio['amount'] < $amount) {
                    throw new Exception("Not enough cryptocurrency to sell.");
                }
                
                // Update portfolio
                $stmt = $pdo->prepare("
                    UPDATE portfolio 
                    SET amount = amount - ?, 
                        last_updated = NOW() 
                    WHERE user_id = ? AND crypto_id = ?
                ");
                $stmt->execute([$amount, $user_id, $crypto_id]);
                
                // Remove entry if amount is 0
                $stmt = $pdo->prepare("
                    DELETE FROM portfolio 
                    WHERE user_id = ? AND crypto_id = ? AND amount <= 0
                ");
                $stmt->execute([$user_id, $crypto_id]);
            }
            
            // Commit transaction
            $pdo->commit();
            
            $response = [
                'success' => true,
                'message' => "Transaction completed successfully."
            ];
        } catch(Exception $e) {
            // Rollback transaction on error
            $pdo->rollBack();
            
            $response = [
                'success' => false,
                'message' => "Error: " . $e->getMessage()
            ];
        }
    }
    
    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}
?>
