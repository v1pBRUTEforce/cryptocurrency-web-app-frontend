<?php
require_once 'config.php';

// Check if user is logged in
redirectIfNotLoggedIn();

// Function to get cryptocurrency data from CoinGecko API
function getCryptoData() {
    $url = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false";
    
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
        return ["error" => "cURL Error #:" . $err];
    } else {
        return json_decode($response, true);
    }
}

// Get cryptocurrency data
$cryptoData = getCryptoData();

// Return JSON response
header('Content-Type: application/json');
echo json_encode($cryptoData);
?>
