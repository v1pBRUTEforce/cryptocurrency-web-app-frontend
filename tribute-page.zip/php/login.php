<?php
require_once 'config.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $email = sanitizeInput($_POST['email']);
    $password = $_POST['password'];
    
    // Prepare a response array
    $response = array();
    
    // Validate input
    if (empty($email) || empty($password)) {
        $response['success'] = false;
        $response['message'] = "Please fill in all fields.";
    } else {
        try {
            // Check if the email exists
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            
            if ($stmt->rowCount() > 0) {
                $user = $stmt->fetch();
                
                // Verify the password
                if (password_verify($password, $user['password'])) {
                    // Password is correct, start a new session
                    session_start();
                    
                    // Store data in session variables
                    $_SESSION["user_id"] = $user["id"];
                    $_SESSION["username"] = $user["name"];
                    $_SESSION["email"] = $user["email"];
                    
                    // Return success response
                    $response['success'] = true;
                    $response['username'] = $user["name"];
                    $response['message'] = "Login successful!";
                } else {
                    // Password is not correct
                    $response['success'] = false;
                    $response['message'] = "Invalid password.";
                }
            } else {
                // Email doesn't exist
                $response['success'] = false;
                $response['message'] = "No account found with that email.";
            }
        } catch(PDOException $e) {
            $response['success'] = false;
            $response['message'] = "Error: " . $e->getMessage();
        }
    }
    
    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}
?>
