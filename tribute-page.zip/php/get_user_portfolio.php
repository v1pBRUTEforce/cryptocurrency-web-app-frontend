<?php
require_once 'config.php';

// Check if user is logged in
redirectIfNotLoggedIn();

// Get user ID from session
$user_id = $_SESSION['user_id'];

try {
    // Get user's portfolio
    $stmt = $pdo->prepare("
        SELECT p.*, c.name, c.symbol, c.current_price 
        FROM portfolio p
        JOIN cryptocurrencies c ON p.crypto_id = c.id
        WHERE p.user_id = ?
    ");
    $stmt->execute([$user_id]);
    $portfolio = $stmt->fetchAll();
    
    // Calculate total portfolio value
    $total_value = 0;
    foreach ($portfolio as &$item) {
        $item['value'] = $item['amount'] * $item['current_price'];
        $total_value += $item['value'];
    }
    
    // Add percentage to each item
    foreach ($portfolio as &$item) {
        $item['percentage'] = ($total_value > 0) ? ($item['value'] / $total_value) * 100 : 0;
    }
    
    // Prepare response
    $response = [
        'success' => true,
        'portfolio' => $portfolio,
        'total_value' => $total_value
    ];
} catch(PDOException $e) {
    $response = [
        'success' => false,
        'message' => "Error: " . $e->getMessage()
    ];
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
