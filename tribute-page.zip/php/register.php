<?php
require_once 'config.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $name = sanitizeInput($_POST['name']);
    $email = sanitizeInput($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Prepare a response array
    $response = array();
    
    // Validate input
    if (empty($name) || empty($email) || empty($password) || empty($confirm_password)) {
        $response['success'] = false;
        $response['message'] = "Please fill in all fields.";
    } elseif ($password != $confirm_password) {
        $response['success'] = false;
        $response['message'] = "Passwords do not match.";
    } else {
        try {
            // Check if email already exists
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            
            if ($stmt->rowCount() > 0) {
                $response['success'] = false;
                $response['message'] = "Email already exists.";
            } else {
                // Hash the password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                // Insert the new user
                $stmt = $pdo->prepare("INSERT INTO users (name, email, password, created_at) VALUES (?, ?, ?, NOW())");
                $result = $stmt->execute([$name, $email, $hashed_password]);
                
                if ($result) {
                    // Get the new user ID
                    $user_id = $pdo->lastInsertId();
                    
                    // Start a new session
                    session_start();
                    
                    // Store data in session variables
                    $_SESSION["user_id"] = $user_id;
                    $_SESSION["username"] = $name;
                    $_SESSION["email"] = $email;
                    
                    // Return success response
                    $response['success'] = true;
                    $response['username'] = $name;
                    $response['message'] = "Registration successful!";
                } else {
                    $response['success'] = false;
                    $response['message'] = "Something went wrong. Please try again.";
                }
            }
        } catch(PDOException $e) {
            $response['success'] = false;
            $response['message'] = "Error: " . $e->getMessage();
        }
    }
    
    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}
?>
