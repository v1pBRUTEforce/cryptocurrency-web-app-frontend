import { Chart } from "@/components/ui/chart"
document.addEventListener("DOMContentLoaded", () => {
  // Portfolio Chart
  const portfolioCtx = document.getElementById("portfolioChart").getContext("2d")

  // Create gradient for portfolio chart
  const portfolioGradient = portfolioCtx.createLinearGradient(0, 0, 0, 200)
  portfolioGradient.addColorStop(0, "rgba(127, 90, 240, 0.6)")
  portfolioGradient.addColorStop(1, "rgba(127, 90, 240, 0.1)")

  const portfolioChart = new Chart(portfolioCtx, {
    type: "line",
    data: {
      labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
      datasets: [
        {
          label: "Portfolio Value",
          data: [15000, 16200, 15800, 17500, 18200, 19000, 18500, 20000, 21500, 23000, 25000, 27543],
          borderColor: "#7f5af0",
          backgroundColor: portfolioGradient,
          borderWidth: 2,
          pointBackgroundColor: "#7f5af0",
          pointBorderColor: "#ffffff",
          pointRadius: 4,
          pointHoverRadius: 6,
          tension: 0.4,
          fill: true,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false,
        },
        tooltip: {
          mode: "index",
          intersect: false,
          backgroundColor: "#242629",
          titleColor: "#ffffff",
          bodyColor: "#94a1b2",
          borderColor: "#383a3f",
          borderWidth: 1,
          padding: 12,
          displayColors: false,
          callbacks: {
            label: (context) => `$${context.parsed.y.toLocaleString()}`,
          },
        },
      },
      scales: {
        x: {
          grid: {
            display: false,
            drawBorder: false,
          },
          ticks: {
            color: "#94a1b2",
            font: {
              size: 10,
            },
          },
        },
        y: {
          grid: {
            color: "rgba(255, 255, 255, 0.05)",
            drawBorder: false,
          },
          ticks: {
            color: "#94a1b2",
            font: {
              size: 10,
            },
            callback: (value) => "$" + value.toLocaleString(),
          },
        },
      },
    },
  })

  // Distribution Chart
  const distributionCtx = document.getElementById("distributionChart").getContext("2d")

  const distributionChart = new Chart(distributionCtx, {
    type: "doughnut",
    data: {
      labels: ["Bitcoin", "Ethereum", "Cardano", "Others"],
      datasets: [
        {
          data: [45, 30, 15, 10],
          backgroundColor: ["#ff9f43", "#5f27cd", "#54a0ff", "#ee5253"],
          borderWidth: 0,
          hoverOffset: 5,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: "70%",
      plugins: {
        legend: {
          display: false,
        },
        tooltip: {
          backgroundColor: "#242629",
          titleColor: "#ffffff",
          bodyColor: "#94a1b2",
          borderColor: "#383a3f",
          borderWidth: 1,
          padding: 12,
          displayColors: true,
          callbacks: {
            label: (context) => `${context.label}: ${context.parsed}%`,
          },
        },
      },
    },
  })
})
