document.addEventListener("DOMContentLoaded", () => {
  // DOM Elements
  const sidebarToggle = document.getElementById("sidebarToggle")
  const sidebar = document.querySelector(".sidebar")
  const loginBtn = document.getElementById("loginBtn")
  const loginModal = document.getElementById("loginModal")
  const closeModal = document.querySelector(".close-modal")
  const showRegisterForm = document.getElementById("showRegisterForm")
  const showLoginForm = document.getElementById("showLoginForm")
  const loginForm = document.getElementById("loginForm")
  const registerForm = document.getElementById("registerForm")
  const addFundsBtn = document.getElementById("addFundsBtn")

  // Toggle sidebar on mobile
  sidebarToggle.addEventListener("click", () => {
    sidebar.classList.toggle("active")
  })

  // Close sidebar when clicking outside on mobile
  document.addEventListener("click", (event) => {
    if (window.innerWidth <= 768) {
      if (!sidebar.contains(event.target) && !sidebarToggle.contains(event.target)) {
        sidebar.classList.remove("active")
      }
    }
  })

  // Show login modal
  loginBtn.addEventListener("click", () => {
    loginModal.style.display = "flex"
  })

  // Close modal
  closeModal.addEventListener("click", () => {
    loginModal.style.display = "none"
  })

  // Close modal when clicking outside
  window.addEventListener("click", (event) => {
    if (event.target === loginModal) {
      loginModal.style.display = "none"
    }
  })

  // Switch between login and register forms
  showRegisterForm.addEventListener("click", (e) => {
    e.preventDefault()
    loginForm.style.display = "none"
    registerForm.style.display = "block"
  })

  showLoginForm.addEventListener("click", (e) => {
    e.preventDefault()
    registerForm.style.display = "none"
    loginForm.style.display = "block"
  })

  // Handle login form submission
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault()
    const email = document.getElementById("email").value
    const password = document.getElementById("password").value

    // In a real app, you would send this data to the server
    console.log("Login attempt:", { email, password })

    // For demo purposes, simulate a successful login
    document.getElementById("username").textContent = email.split("@")[0]
    loginBtn.textContent = "Logout"
    loginModal.style.display = "none"

    // You would normally handle this with AJAX and PHP
    // fetch('php/login.php', {
    //   method: 'POST',
    //   body: new FormData(loginForm)
    // })
    // .then(response => response.json())
    // .then(data => {
    //   if (data.success) {
    //     document.getElementById('username').textContent = data.username;
    //     loginBtn.textContent = 'Logout';
    //     loginModal.style.display = 'none';
    //   } else {
    //     alert(data.message);
    //   }
    // });
  })

  // Handle register form submission
  registerForm.addEventListener("submit", (e) => {
    e.preventDefault()
    const name = document.getElementById("regName").value
    const email = document.getElementById("regEmail").value
    const password = document.getElementById("regPassword").value
    const confirmPassword = document.getElementById("regConfirmPassword").value

    if (password !== confirmPassword) {
      alert("Passwords do not match!")
      return
    }

    // In a real app, you would send this data to the server
    console.log("Registration attempt:", { name, email, password })

    // For demo purposes, simulate a successful registration
    document.getElementById("username").textContent = name
    loginBtn.textContent = "Logout"
    loginModal.style.display = "none"

    // You would normally handle this with AJAX and PHP
    // fetch('php/register.php', {
    //   method: 'POST',
    //   body: new FormData(registerForm)
    // })
    // .then(response => response.json())
    // .then(data => {
    //   if (data.success) {
    //     document.getElementById('username').textContent = data.username;
    //     loginBtn.textContent = 'Logout';
    //     loginModal.style.display = 'none';
    //   } else {
    //     alert(data.message);
    //   }
    // });
  })

  // Load market data
  loadMarketData()
})

// Function to load market data
function loadMarketData() {
  // In a real app, you would fetch this data from an API
  const marketData = [
    {
      name: "Bitcoin",
      symbol: "BTC",
      price: 42385.67,
      change: 2.34,
      marketCap: 824.5,
      icon: "https://cryptologos.cc/logos/bitcoin-btc-logo.png",
    },
    {
      name: "Ethereum",
      symbol: "ETH",
      price: 2286.43,
      change: -1.27,
      marketCap: 274.8,
      icon: "https://cryptologos.cc/logos/ethereum-eth-logo.png",
    },
    {
      name: "Cardano",
      symbol: "ADA",
      price: 0.52,
      change: 5.63,
      marketCap: 18.2,
      icon: "https://cryptologos.cc/logos/cardano-ada-logo.png",
    },
    {
      name: "Solana",
      symbol: "SOL",
      price: 102.75,
      change: 8.91,
      marketCap: 43.6,
      icon: "https://cryptologos.cc/logos/solana-sol-logo.png",
    },
    {
      name: "Polkadot",
      symbol: "DOT",
      price: 6.84,
      change: -0.52,
      marketCap: 8.7,
      icon: "https://cryptologos.cc/logos/polkadot-new-dot-logo.png",
    },
  ]

  const tableBody = document.getElementById("marketTableBody")

  marketData.forEach((coin) => {
    const row = document.createElement("tr")

    const changeClass = coin.change >= 0 ? "positive" : "negative"
    const changeIcon = coin.change >= 0 ? "fa-caret-up" : "fa-caret-down"

    row.innerHTML = `
      <td>
        <div class="coin-info">
          <img src="${coin.icon}" alt="${coin.name}" class="coin-icon">
          <div class="coin-name">
            <span>${coin.name}</span>
            <span>${coin.symbol}</span>
          </div>
        </div>
      </td>
      <td>$${coin.price.toLocaleString()}</td>
      <td class="price-change ${changeClass}">
        ${coin.change}% <i class="fas ${changeIcon}"></i>
      </td>
      <td>$${coin.marketCap}B</td>
      <td>
        <div class="table-actions">
          <button class="btn btn-sm primary">Buy</button>
          <button class="btn btn-sm" style="background-color: var(--background-dark);">Sell</button>
        </div>
      </td>
    `

    tableBody.appendChild(row)
  })
}
