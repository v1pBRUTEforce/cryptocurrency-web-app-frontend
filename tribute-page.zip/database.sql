-- Create database
CREATE DATABASE IF NOT EXISTS bitchest_db;
USE bitchest_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Cryptocurrencies table
CREATE TABLE IF NOT EXISTS cryptocurrencies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    symbol VARCHAR(10) NOT NULL,
    current_price DECIMAL(18, 8) NOT NULL,
    market_cap DECIMAL(24, 2),
    last_updated DATETIME NOT NULL
);

-- Portfolio table
CREATE TABLE IF NOT EXISTS portfolio (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    crypto_id INT NOT NULL,
    amount DECIMAL(18, 8) NOT NULL,
    last_updated DATETIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (crypto_id) REFERENCES cryptocurrencies(id),
    UNIQUE KEY user_crypto (user_id, crypto_id)
);

-- Transactions table
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    crypto_id INT NOT NULL,
    type ENUM('buy', 'sell', 'transfer') NOT NULL,
    amount DECIMAL(18, 8) NOT NULL,
    price DECIMAL(18, 8) NOT NULL,
    transaction_date DATETIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (crypto_id) REFERENCES cryptocurrencies(id)
);

-- Watchlist table
CREATE TABLE IF NOT EXISTS watchlist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    crypto_id INT NOT NULL,
    added_at DATETIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (crypto_id) REFERENCES cryptocurrencies(id),
    UNIQUE KEY user_crypto (user_id, crypto_id)
);

-- Insert sample cryptocurrencies
INSERT INTO cryptocurrencies (name, symbol, current_price, market_cap, last_updated) VALUES
('Bitcoin', 'BTC', 42385.67, 824500000000, NOW()),
('Ethereum', 'ETH', 2286.43, 274800000000, NOW()),
('Cardano', 'ADA', 0.52, 18200000000, NOW()),
('Solana', 'SOL', 102.75, 43600000000, NOW()),
('Polkadot', 'DOT', 6.84, 8700000000, NOW());
